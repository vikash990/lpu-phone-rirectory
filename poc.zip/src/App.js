import {BrowserRouter as Router,Routes,Route} from 'react-router-dom'
import Home from  './components/home';
import Subscriber from './components/addSubscriber';
function App() {

  const phoneDirectory=[    // mock data it is a dumydata
    {
        "name":"Vikash Dubey",
        "phoneNumber":"123456",
    },{
        "name":"Rahul Pandey",
        "phoneNumber":"86788",
    }
]

  return (
    <div className="myApp">
    <Router>
      <Routes>
       <Route path="/" element={<Home phoneDirectory={phoneDirectory} />}></Route>
       <Route path="/add" element={<Subscriber/>}></Route>
      </Routes>
    </Router>
    </div>
  );
}

export default App;
