import {Link} from 'react-router-dom';
import {useState} from 'react';
import "./styles/home.css";
import  Header  from "./common/header";
import Button from "./common/button";

function Home(props){
    
    

    return(
        <div>
        <Header header="PHONE DIRECTORY"/>
        <Link to="/add"><button>Add</button></Link>
        <div>
            <h4 className="phone-name">Name</h4>
            <h4 className="phone-number">Number</h4>
        </div>
           {
               props.phoneDirectory.map((item)=>{
                   return(
                       <div class="subscriber">
                         <p>{item.name}</p>
                         <p>{item.phoneNumber}</p>
                         <Button text="Delete"/>
                       </div>
                   )
               })
           } 
        </div>
    )
}

export default Home;