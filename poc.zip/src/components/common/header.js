
function Header(props){

    return(
    <div>
       <header className="header" >{props.header}</header>
    </div>
)

}

export default Header;
