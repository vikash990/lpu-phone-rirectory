import { Link } from 'react-router-dom'
import { useState } from 'react';
import Header from "./common/header";
import Button from "./common/button";
import "./styles/subscriber.css"

function Subscriber() {

  const [name,setName]=useState("");
  const [number,setNumber]=useState("")

  function handleSubmit(e){
    e.preventDefault();
    console.log(name,number);
  }

  function handleChangeName(e){
   
   setName(e.target.value);
  }

  function handleChangeNumber(e){
    setNumber(e.target.value);
  
   }

  return (
    <div>
      <div className="add">
        <Header header="ADD SUBSCRIBER" />

        <Link to="/"><button>back</button></Link>

        <form onSubmit={handleSubmit}>

          <label>Name:</label><input type="text" value={name} onChange={handleChangeName}/>
          <label>Number:</label><input type="text" value={number} onChange={handleChangeNumber}/>
          <Button text="Add " />

        </form>

      </div>
    </div>
  )
}

export default Subscriber;